# Candidate No:

MIN = -1000
MAX = 1000


class CompactList:
    def __init__(self, alist=[]):
        """
        Constructs a new CompactList object.
        Parameters:
        alist : list, optional
            The list to initialize the CompactList object with. The default is an empty list.
        """
        self.ranges = []
        # If the given list is empty, we can return as there is nothing to initialize
        if len(alist) == 0:
            return
        # Initialize the start and end variables to the first element of the list
        start = end = alist[0]
        # Iterate over the remaining elements of the list
        for num in alist[1:]:
            # If the current number is consecutive to the previous number, extend the current range
            if num == end + 1:
                end = num
            else:
                # If the current number is not consecutive to the previous number, add the previous range
                # to the list of ranges and start a new range
                self.ranges.append((start, end+1))
                start = end = num
        # Add the last range to the list of ranges
        self.ranges.append((start, end+1))

    def cardinality(self):
        """
        Returns the number of elements in the CompactList object.
        Returns
        int
            The number of elements in the CompactList object.
        """
        return sum(end - start for start, end in self.ranges)

    def insert(self, value):
        """
        Inserts an element into the CompactList object
        Parameters:
        value : int
            The value to be inserted.
        """
        if(self.contains(value)):
            return
        # Iterate over the ranges in the CompactList object
        for i, (start, end) in enumerate(self.ranges):
            # If the value is one less than the start of the current range, extend the current range to include the value
            if value == start - 1:
                self.ranges[i] = (value, end)
                # If the extended range overlaps with the previous range, merge the two ranges
                if i > 0 and self.ranges[i][0] == self.ranges[i-1][1]:
                    self.ranges[i] = (self.ranges[i-1][0], self.ranges[i][1])
                    self.ranges.pop(i-1)
                return
            # If the value is equal to the end of the current range, extend the current range to include the value
            elif value == end:
                self.ranges[i] = (start, end+1)
                # If the extended range overlaps with the next range, merge the two ranges
                if i < len(self.ranges) - 1 and self.ranges[i][1] == self.ranges[i+1][0]:
                    self.ranges[i] = (self.ranges[i][0], self.ranges[i+1][1])
                    self.ranges.pop(i+1)
                return
            # If the value is less than the start of the current range, insert a new range for the value
            elif value < start:
                self.ranges.insert(i, (value, value+1))
                return
        # If the value is greater than any range in the CompactList object, add a new range for the value
        self.ranges.append((value, value+1))

    def delete(self, value):
        """
        Deletes the given value from the CompactList object.
        Parameters:
        value : int
            The value to be deleted from the CompactList object.
        """
        if not self.contains(value):
            return
        for i, (start, end) in enumerate(self.ranges):
            if value >= start and value < end:
                if start == end - 1:
                    # If the range has only one element, remove it from the list of ranges
                    self.ranges.pop(i)
                    return
                elif value == start:
                    # If the value is at the start of the range, increment the start of the range
                    self.ranges[i] = (start+1, end)
                    return
                elif value == end - 1:
                    # If the value is at the end of the range, decrement the end of the range
                    self.ranges[i] = (start, end-1)
                    return
                else:
                    # If the value is in the middle of the range, split the range into two
                    self.ranges.insert(i+1, (value+1, end))
                    self.ranges[i] = (start, value)
                    return
        return

    def contains(self, value):
        """
        Checks if the CompactList object contains the given value.
        Parameters
        value : int
            The value to check if it is contained in the CompactList object.
        Returns:
        bool
            True if the CompactList object contains the given value, False otherwise.
        """
        left = 0
        right = len(self.ranges) - 1

        while left <= right:
            mid = (left + right) // 2
            start, end = self.ranges[mid]
            if value < start:
                right = mid - 1
            elif value >= end:
                left = mid + 1
            else:
                return True

        return False

    def subsetOf(self, cl):
        """
        Checks if the set represented by this CompactList object is a subset of the set represented by cl.
        Parameters
        cl : CompactList
            The CompactList object to check if it is a superset of this CompactList object.

        Returns:
        bool
            True if the set represented by this CompactList object is a subset of the
            """
        i = j = 0
        while i < len(self.ranges) and j < len(cl.ranges):
            if self.ranges[i][0] >= cl.ranges[j][1]:
                j += 1
            elif self.ranges[i][1] <= cl.ranges[j][0]:
                i += 1
            else:
                return False
        return True

    def equal(self, cl):
        if len(self.ranges) != len(cl.ranges):
            return False
        for i in range(len(self.ranges)):
            if self.ranges[i] != cl.ranges[i]:
                return False
        return True

    def isEmpty(self):
        return len(self.ranges) == 0

    def complement(self):
        # Initialize an empty list to store complement ranges
        comp_ranges = []

        # If the original list of ranges is empty, add a range that covers the entire possible range
        if len(self.ranges) == 0:
            comp_ranges.append((MIN, MAX+1))
        else:
            # If the first range in the original list doesn't start at the beginning of the possible range, add a range that covers the gap
            if self.ranges[0][0] > MIN:
                comp_ranges.append((MIN, self.ranges[0][0]))

            # Loop through the original list of ranges and find gaps between them, add these to the complement ranges list
            for i in range(1, len(self.ranges)):
                start = self.ranges[i-1][1]
                end = self.ranges[i][0]
                if end > start:
                    comp_ranges.append((start, end))

            # If the last range in the original list doesn't cover the end of the possible range, add a range that covers the gap
            if self.ranges[-1][1] < MAX+1:
                comp_ranges.append((self.ranges[-1][1], MAX+1))

        # Create a new CompactList object using the complement ranges list and return it
        return CompactList._from_ranges(comp_ranges)

    @staticmethod
    def _from_ranges(ranges):
        compact_list = CompactList()
        compact_list.ranges = ranges
        return compact_list
    # def complement(self):

    def Union(self, cl):
        # Create a new compact list to hold the union of the two sets
        union_list = CompactList()
        # Initialize indices to traverse both compact lists
        i = j = 0
        # Get the length of both compact lists
        m = len(self.ranges)
        n = len(cl.ranges)

        # Traverse both compact lists until we reach the end of one of them
        while i < m and j < n:
            # Get the current range of both compact lists
            r1 = self.ranges[i]
            r2 = cl.ranges[j]
            # Check if the ranges overlap
            if r1[1] < r2[0]:
                # If they don't overlap, add the range from the first compact list to the union list
                union_list.ranges.append(r1)
                i += 1
            elif r2[1] < r1[0]:
                # If they don't overlap, add the range from the second compact list to the union list
                union_list.ranges.append(r2)
                j += 1
            else:
                # If they overlap, merge the ranges and add the merged range to the union list
                union_list.ranges.append(
                    (min(r1[0], r2[0]), max(r1[1], r2[1])))
                i += 1
                j += 1

        # Add any remaining ranges from the first compact list to the union list
        while i < m:
            union_list.ranges.append(self.ranges[i])
            i += 1

        # Add any remaining ranges from the second compact list to the union list
        while j < n:
            union_list.ranges.append(cl.ranges[j])
            j += 1

        # Return the union list
        return union_list

    def intersection(self, cl):
        # Initialize an empty list to store the intersection result
        result = []
        # Initialize two pointers for both compact lists
        i = j = 0
        # Loop through the compact lists while the pointers are not out of bounds
        while i < len(self.ranges) and j < len(cl.ranges):
            # Get the start and end values for each compact list
            a_start, a_end = self.ranges[i]
            b_start, b_end = cl.ranges[j]
            # If the end of the first range is before the start of the second range, move the pointer of the first compact list
            if a_end <= b_start:
                i += 1
            # If the end of the second range is before the start of the first range, move the pointer of the second compact list
            elif b_end <= a_start:
                j += 1
            # If there is an overlap between the two ranges, add the intersected range to the result list
            else:
                start = max(a_start, b_start)
                end = min(a_end, b_end)
                result.append((start, end))
                # Move the pointer of the first compact list if the end of the first range is less than or equal to the end of the second range
                if a_end <= b_end:
                    i += 1
                # Move the pointer of the second compact list if the end of the second range is less than or equal to the end of the first range
                if b_end <= a_end:
                    j += 1
        # Return a new compact list with the numbers in the intersected ranges
        return CompactList([num for start, end in result for num in range(start, end)])

    def difference(self, cl):
        # A \ B = A ∩ Bc
        B = cl.complement()
        Diff = self.intersection(B)
        return Diff

    def __str__(self):
        if len(self.ranges) == 0:
            return "empty"
        else:
            result = []
            for start, end in self.ranges:
                result.append(f"<{start},{end-1}>")  # join them with U
            return " U ".join(result)


if __name__ == "__main__":

    mycl1 = CompactList([3, 4, 5, 6, 8, 9, 11])
    print(mycl1.complement().ranges)
    print(mycl1.cardinality())

    mycl2 = CompactList([3, 4, 5, 8, 9])
    print(mycl2)
    print(mycl2.cardinality())
    print(mycl2, "contains 4:", mycl2.contains(4))

    mycl1 = mycl2.complement()
    print(mycl1)
    print(mycl1.cardinality())

    mycl1 = CompactList([MAX])
    print(mycl1)
    print(mycl1.cardinality())
